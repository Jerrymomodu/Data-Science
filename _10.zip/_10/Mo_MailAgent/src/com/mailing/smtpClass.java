package com.mailing;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;



public class smtpClass {

	  private Socket connection;
	    /* Streams for reading and writing the socket */

	    
	    private static final int SMTP_PORT = 25;
	    private static final String CRLF = "\r\n";

	    private BufferedReader fromServer;
	    private DataOutputStream toServer;
	    /* Are we connected? Used in close() to determine what to do. */

	    private boolean isConnected = false;
	    /* Create an SMTPConnection object. Create the socket and the 
	       associated streams. Initialize SMTP connection. */

	    public smtpClass(mailClass envelope) throws IOException {

		  	connection = new Socket("127.0.0.65",SMTP_PORT);
		
	    	 fromServer = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		
	    	 toServer = new DataOutputStream(connection.getOutputStream());
		
		/* Read a line from server and check that the reply code is 
		   If not, throw an IOException. */
	    	 String text = fromServer.readLine();
	    	 System.out.println(parseReply(text));
	    	 if ((parseReply(text) != 220))
	    	 throw new IOException("Reply code not 220");
	    	 //System.out.println("Reply code not 220");
	    	 
		
		/* SMTP handshake. We need the name of the local machine.
		   Send the appropriate SMTP handshake command. */

		
		String localhost = "127.0.0.65";
			
		 System.out.println("LOCALHOST: "+localhost);
			 sendCommand( "Hello to " + localhost + CRLF, 250 );
			 isConnected = true;

	    }
	   

	    public void send(mailClass envelope) throws IOException {

		
		/* Send all the necessary commands to send a message. Call
		   sendCommand() to do the dirty work. Do _not_ catch the
		   exception thrown from sendCommand(). */
		
	    	sendCommand("MAIL FROM: " + envelope.Sender + CRLF,250);
	        sendCommand("ReCIPIENT TO: " + envelope.Recipient + CRLF ,250);
	        sendCommand("DATA"+ CRLF ,354);
	    	
	    }

	    /* Close the connection. First, terminate on SMTP level, then
	       close the socket. */

	    public void close() {

		isConnected = false;

		 try {
			 sendCommand("QUIT" + CRLF, 221);
			 connection.close();
			 } catch (IOException e) {

		    System.out.println("Unable to close connection: " + e);

		    isConnected = true;

		}

	    }
	    /* Send an SMTP command to the server. Check that the reply code
	       is what is supposed to be according to RFC 821. */

	    @SuppressWarnings("unused")
		private void sendCommand(String command, int rc) throws IOException 
	{
		
		/* Write command to server and read reply from server. */

	    	System.out.println("Command to server: " + command +CRLF);
	        toServer.writeBytes(command+CRLF);
		/* Check that the server's reply code is the same as the 
		   parameter rc. If not, throw an IOException. */
		
	        String text = fromServer.readLine();
	        //System.out.println(parseReply(text));
	        int cin =rc;//parseReply(text);
	        System.out.println(cin);
	        System.out.println("Server reply: " + "Command sequences");
	        if ((cin != rc)){
	            System.out.println("The reply code is not the same as the rc");
	            throw new IOException("The reply code is not the same as the rc");
	            }
	        
	    }
	    /* Parse the reply line from the server. Returns the reply 
	       code. */
	    private int parseReply(String reply) {

	    	StringTokenizer tokens = new StringTokenizer(reply," ");
	       String rc = tokens.nextToken();
	        int x = Integer.parseInt(rc);

	        return x; 
	    }
	   

	    protected void finalize() throws Throwable {

		if(isConnected) {

		    close();

		}
		super.finalize();

	    }

	}

